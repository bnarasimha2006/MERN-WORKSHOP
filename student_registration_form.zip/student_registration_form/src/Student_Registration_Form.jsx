import { useState } from 'react';
import { TextField, Button } from '@mui/material';

function RegistrationForm() {
    //fullName,Email,PhoneNumber,
    //Address,submit,Reset Button
    const [fullName, setFullName] = useState('');
    const [PhoneNumber, setPhoneNumber] = useState('')
    const [Email, setEmail] = useState('')
    const [Address, setAddress] = useState('')

    function handleSubmit() {
        //step1: check wheather all fields are entered
        if (!fullName) {
            alert ('please fill all the mandatory fields');
            return;
        }
        // step2: store the form data in database - later
        // step3: alert about successfull submit
        alert(` Thanks for registering. Your details:
            Full Name: ${fullName}
            Phone Number: ${PhoneNumber}
            Email: ${Email}
            Address: ${Address}
            ` );
        //step4: clear the form fields
        setFullName("");
        setPhoneNumber("");
        setEmail("");
        setAddress('');
    }
    function reset(){
         setFullName("");
        setPhoneNumber("");
        setEmail("");
        setAddress('');

    }
    return (
        <div>
            <form onSubmit={handleSubmit}
            onReset={reset}>
                <TextField
                label="FullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                fullWidth
                margin="normal"
                required
                />
                <TextField type='number'
                label="PhoneNumber"
                value={PhoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                fullWidth
                margin="normal"
                required
                 />
                <TextField
                type='email'
                label="Email"
                value={Email}
                onChange={(e) => setEmail(e.target.value)}
                fullWidth
                margin="normal"
                required
                 />
                 <TextField
                 label="Address"
                 value={Address}
                 onChange={(e) => setAddress(e.target.value)}
                 fullWidth
                 margin="normal"
                 multiline
                 rows={3}
                 required
                  />
                <Button type="submit" variant="contained" color="primary" sx={{mr:3}}>Submit</Button>
                <Button type="reset" variant="contained" color="secondary">Reset</Button>
            </form>

        </div>
    );
}
export default RegistrationForm;